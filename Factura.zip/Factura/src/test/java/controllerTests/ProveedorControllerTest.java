/*package controllerTests;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import tiendas.factura.Controller.proveedorController;
import tiendas.factura.Models.Proveedor;

import java.util.List;
import java.util.Scanner;

import static org.junit.jupiter.api.Assertions.*;

public class ProveedorControllerTest {

    private proveedorController controller;

    @BeforeEach
    public void setUp() {
        controller = new proveedorController();
    }

    @Test
    public void testAgregarProveedor() {
        Proveedor proveedor = new Proveedor(1, "Proveedor1", "Dirección1", "1234567890", "proveedor1@example.com", "NIT12345");
        controller.agregarProveedor(proveedor);
        List<Proveedor> proveedores = controller.obtenerProveedores();
        assertTrue(proveedores.contains(proveedor));
    }

    @Test
    public void testObtenerProveedorPorId() {
        Proveedor proveedor = new Proveedor(2, "Proveedor2", "Dirección2", "9876543210", "proveedor2@example.com", "NIT67890");
        controller.agregarProveedor(proveedor);
        Proveedor proveedorObtenido = controller.obtenerProveedorPorId(2);
        assertNotNull(proveedorObtenido);
        assertEquals(proveedor, proveedorObtenido);
    }

    @Test
    public void testActualizarProveedor() {
        Proveedor proveedor = new Proveedor(3, "Proveedor3", "Dirección3", "5555555555", "proveedor3@example.com", "NIT11111");
        controller.agregarProveedor(proveedor);

        Proveedor proveedorActualizado = new Proveedor(3, "NuevoProveedor", "NuevaDirección", "9999999999", "nuevo@example.com", "NIT11111");
        controller.actualizarProveedor(proveedorActualizado);

        Proveedor proveedorObtenido = controller.obtenerProveedorPorId(3);
        assertNotNull(proveedorObtenido);
        assertEquals(proveedorActualizado, proveedorObtenido);
    }

    @Test
    public void testEliminarProveedor() {
        Proveedor proveedor = new Proveedor(4, "Proveedor4", "Dirección4", "4444444444", "proveedor4@example.com", "NIT22222");
        controller.agregarProveedor(proveedor);

        controller.eliminarProveedor(4);

        Proveedor proveedorEliminado = controller.obtenerProveedorPorId(4);
        assertNull(proveedorEliminado);
    }
}*/