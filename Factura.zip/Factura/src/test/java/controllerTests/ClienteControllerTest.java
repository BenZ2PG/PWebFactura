/**package controllerTests;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.List;
import static org.junit.Assert.*;
import org.junit.Before;
import org.junit.Test;
import tiendas.factura.Models.Cliente;
import tiendas.factura.Controller.clienteController;

public class ClienteControllerTest {

    private clienteController controller;

    @Before
    public void setUp() {
        controller = new clienteController();
    }

    @Test
    public void testAgregarCliente() {
        Cliente cliente = new Cliente("John", "Doe", 123456789, "john@example.com", "123-456-7890");
        controller.agregarCliente(cliente);

        // Obtener la lista de clientes y verificar si contiene el cliente agregado
        assertTrue(controller.obtenerClientes().contains(cliente));
    }

    @Test
    public void testObtenerClientePorCedula() {
        Cliente cliente = new Cliente("Alice", "Smith", 987654321, "alice@example.com", "987-654-3210");
        controller.agregarCliente(cliente);

        // Verificar si se puede obtener el cliente por cédula
        Cliente clienteEncontrado = controller.obtenerClientePorCedula(987654321);
        assertNotNull(clienteEncontrado);
        assertEquals(cliente, clienteEncontrado);

        // Verificar cuando no se encuentra un cliente
        assertNull(controller.obtenerClientePorCedula(123456789));
    }

    @Test
    public void testActualizarCliente() {
        Cliente cliente = new Cliente("Bob", "Johnson", 111111111, "bob@example.com", "111-111-1111");
        controller.agregarCliente(cliente);

        Cliente clienteActualizado = new Cliente("Updated", "Name", 111111111, "updated@example.com", "999-999-9999");
        controller.actualizarCliente(clienteActualizado);

        // Verificar si el cliente se actualizó correctamente
        Cliente clienteObtenido = controller.obtenerClientePorCedula(111111111);
        assertNotNull(clienteObtenido);
        assertEquals(clienteActualizado, clienteObtenido);
    }

    @Test
    public void testEliminarCliente() {
        Cliente cliente = new Cliente("Eva", "Williams", 555555555, "eva@example.com", "555-555-5555");
        controller.agregarCliente(cliente);

        // Verificar que el cliente se elimina correctamente
        controller.eliminarCliente(555555555);
        assertNull(controller.obtenerClientePorCedula(555555555));
    }


        
    }
**/