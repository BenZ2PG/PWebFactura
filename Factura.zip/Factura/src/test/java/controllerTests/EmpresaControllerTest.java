/**package controllerTests;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import java.io.*;
import java.util.List;
import java.util.Scanner;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import tiendas.factura.Controller.empresaController;
import tiendas.factura.Models.Empresa;

public class EmpresaControllerTest {

    private empresaController controller;
    private final ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
    private final PrintStream originalOut = System.out;

    @BeforeEach
    public void setUp() {
        controller = new empresaController();
        System.setOut(new PrintStream(outputStream));
    }

    @Test
    public void testAgregarEmpresa() {
        Empresa empresa = new Empresa("NombreEmpresa", "DireccionEmpresa", "1234567890", "empresa@ejemplo.com", "NIT12345");
        controller.agregarEmpresa(empresa);
        List<Empresa> empresas = controller.obtenerEmpresas();
        assertTrue(empresas.contains(empresa));
    }

    @Test
    public void testObtenerEmpresaPorNit() {
        Empresa empresa = new Empresa("NombreEmpresa", "DireccionEmpresa", "1234567890", "empresa@ejemplo.com", "NIT12345");
        controller.agregarEmpresa(empresa);
        Empresa encontrada = controller.obtenerEmpresaPorNit("NIT12345");
        assertNotNull(encontrada);
        assertEquals(empresa, encontrada);
    }

    @Test
    public void testActualizarEmpresa() {

        Empresa empresa = new Empresa("NombreEmpresa", "DireccionEmpresa", "1234567890", "empresa@ejemplo.com", "NIT13245");
        controller.agregarEmpresa(empresa);
        Empresa empresaActualizada = new Empresa("NuevoNombre", "NuevaDireccion", "0987654321", "nueva@ejemplo.com", "NIT13245");
        controller.actualizarEmpresa(empresaActualizada);
        Empresa empresaObtenida = controller.obtenerEmpresaPorNit("NIT13245");
        assertNotNull(empresaObtenida);
        assertEquals(empresaActualizada, empresaObtenida);
    }

    @Test
    public void testEliminarEmpresa() {
        Empresa empresa = new Empresa("NombreEmpresa", "DireccionEmpresa", "1234567890", "empresa@ejemplo.com", "NIT12345");
        controller.agregarEmpresa(empresa);

        controller.eliminarEmpresa("NIT12345");
        Empresa empresaEliminada = controller.obtenerEmpresaPorNit("NIT12345");
        assertNull(empresaEliminada);
    }

    @AfterEach
    public void tearDown() {
        System.setOut(originalOut);
    }
}
* **/