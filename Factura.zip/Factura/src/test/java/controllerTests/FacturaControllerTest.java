package controllerTests;
/*

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import tiendas.factura.Models.*;
import java.io.*;
import java.util.List;
import org.junit.jupiter.api.AfterEach;
import tiendas.factura.Controller.facturaController;

public class FacturaControllerTest {

    private facturaController controller;
    private final ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
    private final PrintStream originalOut = System.out;

    @BeforeEach
    public void setUp() {
        controller = new facturaController();
        System.setOut(new PrintStream(outputStream));
    }

    @Test
    public void testCrearFactura() {
        Cliente cliente = new Cliente("NombreCliente", "ApellidoCliente", 1234567890, "cliente@ejemplo.com", "CEDULA12345");
        Empleado empleado = new Empleado(1, "NombreEmpleado", "ApellidoEmpleado", "CEDULA54321", "empleado@ejemplo.com", "1234567890", "CargoEmpleado");
        Sucursal sucursal = new Sucursal(1, "Sucursal1", "DireccionSucursal", "1234567890");
        Producto producto = new Producto(1, "10 kg", "kilogramos", "Alimento", "10.0", "USD", "Grande", "1 unidad", "123456", "Producto1", "Descripción del producto");

        controller.crearFactura(1, "2023-09-04", cliente, empleado, sucursal, producto);

        List<Factura> facturas = controller.obtenerTodasLasFacturas();
        assertFalse(facturas.isEmpty());
        assertEquals(1, facturas.size());
    }

    @Test
    public void testObtenerFacturaPorNumero() {
        Cliente cliente = new Cliente("NombreCliente", "ApellidoCliente", 1234567890, "cliente@ejemplo.com", "CEDULA12345");
        Empleado empleado = new Empleado(1, "NombreEmpleado", "ApellidoEmpleado", "CEDULA54321", "empleado@ejemplo.com", "1234567890", "CargoEmpleado");
        Sucursal sucursal = new Sucursal(1, "Sucursal1", "DireccionSucursal", "1234567890");
        Producto producto = new Producto(1, "10 kg", "kilogramos", "Alimento", "10.0", "USD", "Grande", "1 unidad", "123456", "Producto1", "Descripción del producto");

        controller.crearFactura(1, "2023-09-04", cliente, empleado, sucursal, producto);

        Factura facturaObtenida = controller.obtenerFacturaPorNumero(1);
        assertNotNull(facturaObtenida);
        assertEquals(1, facturaObtenida.getNumero());
    }

    @Test
    public void testActualizarFactura() {
        Cliente cliente = new Cliente("NombreCliente", "ApellidoCliente", 1234567890, "cliente@ejemplo.com", "CEDULA12345");
        Empleado empleado = new Empleado(1, "NombreEmpleado", "ApellidoEmpleado", "CEDULA54321", "empleado@ejemplo.com", "1234567890", "CargoEmpleado");
        Sucursal sucursal = new Sucursal(1, "Sucursal1", "DireccionSucursal", "1234567890");
        Producto producto = new Producto(1, "10 kg", "kilogramos", "Alimento", "10.0", "USD", "Grande", "1 unidad", "123456", "Producto1", "Descripción del producto");

        controller.crearFactura(1, "2023-09-04", cliente, empleado, sucursal, producto);

        Factura facturaActualizada = new Factura(1, "2023-09-05", cliente, empleado, sucursal, producto);
        controller.actualizarFactura(facturaActualizada);

        Factura facturaObtenida = controller.obtenerFacturaPorNumero(0);
        assertNotNull(facturaObtenida);
        assertEquals("2023-09-05", facturaObtenida.getFecha());
    }

    @Test
    public void testEliminarFactura() {
        Cliente cliente = new Cliente("NombreCliente", "ApellidoCliente", 1234567890, "cliente@ejemplo.com", "CEDULA12345");
        Empleado empleado = new Empleado(1, "NombreEmpleado", "ApellidoEmpleado", "CEDULA54321", "empleado@ejemplo.com", "1234567890", "CargoEmpleado");
        Sucursal sucursal = new Sucursal(1, "Sucursal1", "DireccionSucursal", "1234567890");
        Producto producto = new Producto(1, "10 kg", "kilogramos", "Alimento", "10.0", "USD", "Grande", "1 unidad", "123456", "Producto1", "Descripción del producto");

        controller.crearFactura(1, "2023-09-04", cliente, empleado, sucursal, producto);

        controller.eliminarFactura(1);

        Factura facturaEliminada = controller.obtenerFacturaPorNumero(1);
        assertNull(facturaEliminada);
    }

    // Otros métodos de prueba según sea necesario
    @AfterEach
    public void tearDown() {
        System.setOut(originalOut); // Restaurar la salida estándar
    }
}
*/