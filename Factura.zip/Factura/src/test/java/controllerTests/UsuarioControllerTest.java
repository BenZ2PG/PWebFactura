/*package controllerTests;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import java.io.IOException;
import java.util.Arrays;
import java.util.List;
import tiendas.factura.Controller.usuarioController;
import tiendas.factura.Models.Usuario;

public class UsuarioControllerTest {

    private usuarioController controller;

    @BeforeEach
    public void setUp() {
        controller = new usuarioController();
    }

    @Test
    public void testAgregarUsuario() {
        Usuario usuario = new Usuario("usuario1", "password1");
        controller.agregarUsuario(usuario);
        assertEquals(3, controller.obtenerUsuarios().size());
    }

    @Test
    public void testObtenerUsuarioPorUsername() {
        Usuario usuario = new Usuario("usuario1", "password1");
        controller.agregarUsuario(usuario);
        Usuario usuarioObtenido = controller.obtenerUsuarioPorUsername("usuario1");
        assertEquals(usuario, usuarioObtenido);
    }

    @Test
    public void testActualizarUsuario() {
        Usuario usuario = new Usuario("usuario1", "password1");
        controller.agregarUsuario(usuario);
        Usuario usuarioActualizado = new Usuario("usuario1", "nuevoPassword");
        controller.actualizarUsuario(usuarioActualizado);
        Usuario usuarioObtenido = controller.obtenerUsuarioPorUsername("usuario1");
        assertEquals(usuarioActualizado, usuarioObtenido);
    }

    @Test
    public void testEliminarUsuario() {
        Usuario usuario = new Usuario("usuario1", "password1");
        controller.agregarUsuario(usuario);
        controller.eliminarUsuario("usuario1");
        assertEquals(2, controller.obtenerUsuarios().size());
    }
}
*/