/*package controllerTests;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import java.io.IOException;
import java.util.Arrays;
import java.util.List;
import tiendas.factura.Controller.sucursalController;
import tiendas.factura.Models.Sucursal;

public class SucursalControllerTest {

    private sucursalController controller;

    @BeforeEach
    public void setUp() {
        controller = new sucursalController();
    }

    @Test
    public void testAgregarSucursal() {
        Sucursal sucursal = new Sucursal(1, "Sucursal1", "Dirección1", "1234567890");
        controller.agregarSucursal(sucursal);
        assertEquals(1, controller.obtenerSucursales().size());
    }

    @Test
    public void testObtenerSucursalPorIds() {
        Sucursal sucursal = new Sucursal(1, "Sucursal1", "Dirección1", "1234567890");
        controller.agregarSucursal(sucursal);
        Sucursal sucursalObtenida = controller.obtenerSucursalPorIds(1);
        assertEquals(sucursal, sucursalObtenida);
    }

    @Test
    public void testActualizarSucursal() {
        Sucursal sucursal = new Sucursal(1, "Sucursal1", "Dirección1", "1234567890");
        controller.agregarSucursal(sucursal);
        Sucursal sucursalActualizada = new Sucursal(1, "NuevaSucursal", "NuevaDirección", "0987654321");
        controller.actualizarSucursal(sucursalActualizada);
        Sucursal sucursalObtenida = controller.obtenerSucursalPorIds(1);
        assertEquals(sucursalActualizada, sucursalObtenida);
    }

    @Test
    public void testEliminarSucursal() {
        Sucursal sucursal = new Sucursal(1, "Sucursal1", "Dirección1", "1234567890");
        controller.agregarSucursal(sucursal);
        controller.eliminarSucursal(1);
        assertEquals(0, controller.obtenerSucursales().size());
    }
}
*/