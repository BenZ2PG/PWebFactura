/*package controllerTests;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import tiendas.factura.Controller.productoController;
import tiendas.factura.Models.Producto;

public class ProductoControllerTest {

    private productoController controller;

    @BeforeEach
    public void setUp() {
        // Configuración común antes de cada prueba
        controller = new productoController();
    }

    @Test
    public void testAgregarProducto() {
        // Crear un nuevo producto
        Producto producto = new Producto(1, "100g", "g", "Alimento", "10.0", "USD", "Pequeño", "1", "P1", "Producto1", "Descripción");

        // Agregar el producto
        controller.agregarProducto(producto);

        // Obtener la lista de productos y verificar si el producto se ha agregado correctamente
        assertTrue(controller.obtenerProductos().contains(producto));
    }

    @Test
    public void testObtenerProductoPorIdp() {
        // Crear productos de prueba
        Producto producto1 = new Producto(1, "100g", "g", "Alimento", "10.0", "USD", "Pequeño", "1", "P1", "Producto1", "Descripción");
        Producto producto2 = new Producto(2, "200g", "g", "Bebida", "5.0", "USD", "Mediano", "1", "P2", "Producto2", "Descripción");

        // Agregar productos a la lista
        controller.agregarProducto(producto1);
        controller.agregarProducto(producto2);

        // Verificar si se puede obtener un producto por ID
        assertEquals(producto1, controller.obtenerProductoPorIdp(1));
        assertEquals(producto2, controller.obtenerProductoPorIdp(2));
        assertNull(controller.obtenerProductoPorIdp(3)); // Producto no existente
    }

    @Test
    public void testActualizarProducto() {
        // Crear un producto de prueba y agregarlo
        Producto productoOriginal = new Producto(1, "100g", "g", "Alimento", "10.0", "USD", "Pequeño", "1", "P1", "Producto1", "Descripción");
        controller.agregarProducto(productoOriginal);

        // Crear un nuevo producto con los mismos atributos pero diferentes valores
        Producto productoActualizado = new Producto(1, "200g", "g", "Bebida", "5.0", "USD", "Mediano", "1", "P2", "Producto2", "Nueva Descripción");

        // Actualizar el producto
        assertTrue(controller.actualizarProducto(1, productoActualizado));

        // Verificar que el producto se ha actualizado correctamente
        Producto productoObtenido = controller.obtenerProductoPorIdp(1);
        assertEquals(productoActualizado, productoObtenido);
    }

    @Test
    public void testEliminarProducto() {
        // Crear productos de prueba
        Producto producto1 = new Producto(1, "100g", "g", "Alimento", "10.0", "USD", "Pequeño", "1", "P1", "Producto1", "Descripción");
        Producto producto2 = new Producto(2, "200g", "g", "Bebida", "5.0", "USD", "Mediano", "1", "P2", "Producto2", "Descripción");

        // Agregar productos a la lista
        controller.agregarProducto(producto1);
        controller.agregarProducto(producto2);

        // Eliminar un producto existente
        assertTrue(controller.eliminarProducto(1));

        // Verificar que el producto se ha eliminado correctamente
        assertNull(controller.obtenerProductoPorIdp(1));
        assertNotNull(controller.obtenerProductoPorIdp(2)); // El otro producto aún debe existir
    }
}*/