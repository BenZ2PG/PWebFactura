/**package controllerTests;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import java.io.*;
import java.util.List;
import java.util.Scanner;
import org.junit.jupiter.api.AfterEach;
import tiendas.factura.Controller.empleadoController;
import tiendas.factura.Models.Empleado;

public class EmpleadoControllerTest {

    private empleadoController controller;
    private final ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
    private final PrintStream originalOut = System.out;

    @BeforeEach
    public void setUp() {
        controller = new empleadoController();
        System.setOut(new PrintStream(outputStream));
    }

    @Test
    public void testAgregarEmpleado() {
        Empleado empleado = new Empleado(2, "Nombres", "Apellidos", "12345678901", "correo@ejemplos.com", "1234567894", "Cargos");
        controller.agregarEmpleado(empleado);
        List<Empleado> empleados = controller.obtenerEmpleados();
        assertTrue(empleados.contains(empleado));
    }

    @Test
    public void testObtenerEmpleadoPorId() {
        Empleado empleado = new Empleado(2, "Nombres", "Apellidos", "12345678901", "correo@ejemplos.com", "1234567894", "Cargos");
        controller.agregarEmpleado(empleado);
        Empleado encontrado = controller.obtenerEmpleadoPorId(2);
        assertNotNull(encontrado);
        assertEquals(empleado, encontrado);
    }

    @Test
    public void testActualizarEmpleado() {
        Empleado empleado = new Empleado(1, "Nombre", "Apellido", "1234567890", "correo@ejemplo.com", "123456789", "Cargo");
        controller.agregarEmpleado(empleado);
        Empleado empleadoActualizado = new Empleado(1, "NuevoNombre", "NuevoApellido", "1234567890", "nuevo@ejemplo.com", "987654321", "NuevoCargo");
        controller.actualizarEmpleado(empleadoActualizado);

        Empleado empleadoObtenido = controller.obtenerEmpleadoPorId(1);
        assertNotNull(empleadoObtenido);
        assertEquals(empleadoActualizado, empleadoObtenido);
    }

    @Test
    public void testEliminarEmpleado() {
        Empleado empleado = new Empleado(1, "Nombre", "Apellido", "1234567890", "correo@ejemplo.com", "123456789", "Cargo");
        controller.agregarEmpleado(empleado);
        controller.eliminarEmpleado(1);

        Empleado empleadoEliminado = controller.obtenerEmpleadoPorId(1);
        assertNull(empleadoEliminado);
    }



    @AfterEach
    public void tearDown() {
        System.setOut(originalOut); // Restaurar la salida estándar
    }
}
**/