package tiendas.factura.Controller;

import tiendas.factura.Models.Usuario;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.io.*;
import tiendas.factura.Models.Main;

public class usuarioController {

    private List<Usuario> usuarios;
    private String filePath = "C:\\Users\\BensY\\OneDrive\\Documentos\\NetBeansProjects\\Factura\\src\\main\\java\\tiendas\\factura\\Files\\Usuarios.txt";

    public usuarioController() {
        usuarios = new ArrayList<>();
    }

    public static void usuarioMenu(Scanner scanner) {
        usuarioController usuarioController = new usuarioController();

        while (true) {
            System.out.println("Menú de Usuarios");
            System.out.println("1. Agregar Usuario");
            System.out.println("2. Buscar Usuario por Username");
            System.out.println("3. Actualizar Usuario");
            System.out.println("4. Eliminar Usuario");
            System.out.println("5. Listar Usuarios");
            System.out.println("0. Salir");
            System.out.print("Ingrese una opción: ");
            int opcion = scanner.nextInt();
            scanner.nextLine(); // Consume la nueva línea

            switch (opcion) {
                case 1:
                    // Agregar Usuario
                    System.out.print("Ingrese username del usuario: ");
                    String username = scanner.nextLine();
                    System.out.print("Ingrese password del usuario: ");
                    String password = scanner.nextLine();
                    Usuario nuevoUsuario = new Usuario(username, password);
                    usuarioController.agregarUsuario(nuevoUsuario);
                    System.out.println("Usuario agregado correctamente.");
                    break;

                case 2:
                    // Buscar Usuario por Username
                    System.out.print("Ingrese username del usuario a buscar: ");
                    String usernameBuscar = scanner.nextLine();
                    Usuario usuarioEncontrado = usuarioController.obtenerUsuarioPorUsername(usernameBuscar);
                    if (usuarioEncontrado != null) {
                        System.out.println("Usuario encontrado:");
                        System.out.println(usuarioEncontrado);
                    } else {
                        System.out.println("Usuario no encontrado.");
                    }
                    break;

                case 3:
                    // Actualizar Usuario
                    System.out.print("Ingrese username del usuario a actualizar: ");
                    String usernameActualizar = scanner.nextLine();
                    Usuario usuarioActualizado = usuarioController.obtenerUsuarioPorUsername(usernameActualizar);
                    if (usuarioActualizado != null) {
                        System.out.print("Ingrese nuevo password del usuario: ");
                        usuarioActualizado.setPassword(scanner.nextLine());

                        usuarioController.actualizarUsuario(usuarioActualizado);
                        System.out.println("Usuario actualizado correctamente.");
                    } else {
                        System.out.println("Usuario no encontrado.");
                    }
                    break;

                case 4:
                    // Eliminar Usuario
                    System.out.print("Ingrese username del usuario a eliminar: ");
                    String usernameEliminar = scanner.nextLine();
                    usuarioController.eliminarUsuario(usernameEliminar);
                    System.out.println("Usuario eliminado correctamente.");
                    break;

                case 5:
                    // Listar Usuarios
                    System.out.println("Listado de Usuarios:");
                    for (Usuario usuario : usuarioController.obtenerUsuarios()) {
                        System.out.println(usuario);
                    }
                    break;

                case 0:
                    Main.mainMenu(); // Volver al Menú Principal
                    return;
                default:
                    System.out.println("Opción inválida.");
                    break;
            }
        }

    }

    public void agregarUsuario(Usuario usuario) {
        usuarios.add(usuario);
    }

    public Usuario obtenerUsuarioPorUsername(String username) {
        for (Usuario usuario : usuarios) {
            if (usuario.getUsername().equals(username)) {
                return usuario;
            }
        }
        return null;
    }

    public void actualizarUsuario(Usuario usuarioActualizado) {
        for (int i = 0; i < usuarios.size(); i++) {
            Usuario usuario = usuarios.get(i);
            if (usuario.getUsername().equals(usuarioActualizado.getUsername())) {
                usuarios.set(i, usuarioActualizado);
                break;
            }
        }
    }

    public void eliminarUsuario(String username) {
        usuarios.removeIf(usuario -> usuario.getUsername().equals(username));
    }

    public List<Usuario> obtenerUsuarios() {
        return usuarios;
    }
}
