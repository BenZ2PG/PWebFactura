package tiendas.factura.Controller;

import tiendas.factura.Models.Sucursal;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.io.*;
import tiendas.factura.Models.Cliente;
import tiendas.factura.Models.Main;

public class sucursalController {

    private List<Sucursal> sucursales;
    private String filePath = "C:\\Users\\BensY\\OneDrive\\Documentos\\NetBeansProjects\\Factura\\src\\main\\java\\tiendas\\factura\\Files\\sucursales.txt";

    public sucursalController() {
        sucursales = new ArrayList<>();
    }

    public static void sucursalMenu(Scanner scanner) {
        sucursalController sucursalController = new sucursalController();

        while (true) {
            System.out.println("Menú de Sucursales");
            System.out.println("1. Agregar Sucursal");
            System.out.println("2. Buscar Sucursal por ID");
            System.out.println("3. Actualizar Sucursal");
            System.out.println("4. Eliminar Sucursal");
            System.out.println("5. Listar Sucursales");
            System.out.println("0. Salir");
            System.out.print("Ingrese una opción: ");
            int opcion = scanner.nextInt();
            scanner.nextLine(); // Consume la nueva línea

            switch (opcion) {
                case 1:
                    // Agregar Sucursal
                    System.out.print("Ingrese ID de la sucursal: ");
                    int ids = scanner.nextInt();
                    scanner.nextLine(); // Consume la nueva línea
                    System.out.print("Ingrese nombre de la sucursal: ");
                    String nombre = scanner.nextLine();
                    System.out.print("Ingrese dirección de la sucursal: ");
                    String direccion = scanner.nextLine();
                    System.out.print("Ingrese teléfono de la sucursal: ");
                    String telefono = scanner.nextLine();

                    Sucursal nuevaSucursal = new Sucursal(ids, nombre, direccion, telefono);
                    sucursalController.agregarSucursal(nuevaSucursal);
                    System.out.println("Sucursal agregada correctamente.");
                    break;

                case 2:
                    // Buscar Sucursal por ID
                    System.out.print("Ingrese ID de la sucursal a buscar: ");
                    int idsBuscar = scanner.nextInt();
                    Sucursal sucursalEncontrada = sucursalController.obtenerSucursalPorIds(idsBuscar);
                    if (sucursalEncontrada != null) {
                        System.out.println("Sucursal encontrada:");
                        System.out.println(sucursalEncontrada);
                    } else {
                        System.out.println("Sucursal no encontrada.");
                    }
                    break;

                case 3:
                    // Actualizar Sucursal
                    System.out.print("Ingrese ID de la sucursal a actualizar: ");
                    int idsActualizar = scanner.nextInt();
                    scanner.nextLine(); // Consume la nueva línea
                    Sucursal sucursalActualizada = sucursalController.obtenerSucursalPorIds(idsActualizar);
                    if (sucursalActualizada != null) {
                        System.out.print("Ingrese nuevo nombre de la sucursal: ");
                        sucursalActualizada.setNombre(scanner.nextLine());
                        System.out.print("Ingrese nueva dirección de la sucursal: ");
                        sucursalActualizada.setDireccion(scanner.nextLine());
                        System.out.print("Ingrese nuevo teléfono de la sucursal: ");
                        sucursalActualizada.setTelefono(scanner.nextLine());

                        sucursalController.actualizarSucursal(sucursalActualizada);
                        System.out.println("Sucursal actualizada correctamente.");
                    } else {
                        System.out.println("Sucursal no encontrada.");
                    }
                    break;

                case 4:
                    // Eliminar Sucursal
                    System.out.print("Ingrese ID de la sucursal a eliminar: ");
                    int idsEliminar = scanner.nextInt();
                    sucursalController.eliminarSucursal(idsEliminar);
                    System.out.println("Sucursal eliminada correctamente.");
                    break;

                case 5:
                    // Listar Sucursales
                    System.out.println("Listado de Sucursales:");
                    for (Sucursal sucursal : sucursalController.obtenerSucursales()) {
                        System.out.println(sucursal);
                    }
                    break;

                case 0:
                    Main.mainMenu(); // Volver al Menú Principal
                    return;
                default:
                    System.out.println("Opción inválida.");
                    break;
            }
        }

    }

    public void agregarSucursal(Sucursal sucursal) {
        sucursales.add(sucursal);
    }

    public Sucursal obtenerSucursalPorIds(int ids) {
        for (Sucursal sucursal : sucursales) {
            if (sucursal.getIds() == ids) {
                return sucursal;
            }
        }
        return null;
    }

    public static Sucursal obtenerSucursalPorIdsS(int Ids) {
        sucursalController sucursalController = new sucursalController();
        return sucursalController.obtenerSucursalPorIds(Ids);
    }

    public void actualizarSucursal(Sucursal sucursalActualizada) {
        for (int i = 0; i < sucursales.size(); i++) {
            Sucursal sucursal = sucursales.get(i);
            if (sucursal.getIds() == sucursalActualizada.getIds()) {
                sucursales.set(i, sucursalActualizada);
                break;
            }
        }
    }

    public void eliminarSucursal(int ids) {
        sucursales.removeIf(sucursal -> sucursal.getIds() == ids);
    }

    public List<Sucursal> obtenerSucursales() {
        return sucursales;
    }
}
