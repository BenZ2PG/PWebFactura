package tiendas.factura.Controller;

import tiendas.factura.Models.Cliente;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import tiendas.factura.Models.Main;
import java.io.*;
import java.util.Iterator;

public class clienteController {

    private List<Cliente> clientes;
    private Scanner scanner;
    public String filePath = "C:\\Users\\BensY\\OneDrive\\Documentos\\NetBeansProjects\\Factura\\src\\main\\java\\tiendas\\factura\\Files\\clientes.txt";

    public clienteController() {
        clientes = new ArrayList<>();

    }

    
    public void agregarCliente(Cliente cliente) {
        clientes.add(cliente);
    }

    public Cliente obtenerClientePorCedula(int cedula) {
        for (Cliente cliente : clientes) {
            if (cliente.getCedula() == cedula) {
                return cliente;
            }
        }
        return null;
    }

    public static Cliente obtenerClientePorCedulaS(int cedula) {
        clienteController clienteController = new clienteController();
        return clienteController.obtenerClientePorCedula(cedula);
    }

    public void actualizarCliente(Cliente clienteActualizado) {
        for (int i = 0; i < clientes.size(); i++) {
            Cliente cliente = clientes.get(i);
            if (cliente.getCedula() == clienteActualizado.getCedula()) {
                clientes.set(i, clienteActualizado);
                break;
            }
        }
    }

    public void eliminarCliente(int cedula) {
        clientes.removeIf(cliente -> cliente.getCedula() == cedula);
    }

    public List<Cliente> obtenerClientes() {
        return clientes;
    }


}
