package tiendas.factura.Controller;

import tiendas.factura.Models.*;
import tiendas.factura.Controller.*;
import java.io.*;
import java.util.ArrayList;
import java.util.List;

public class facturaController {

    private List<Factura> facturas;
    private String filePath = "C:\\Users\\BensY\\OneDrive\\Documentos\\NetBeansProjects\\Factura\\src\\main\\java\\tiendas\\factura\\Files\\Factura.txt";

    public facturaController() {
        facturas = new ArrayList<>();
    }

// Crear una nueva factura
    public void crearFactura(int numero, String fecha, Cliente cliente, Empleado empleado, Sucursal sucursal, Producto productos) {
        Factura nuevaFactura = new Factura(numero, fecha, cliente, empleado, sucursal, productos);
        facturas.add(nuevaFactura);
    }

    // Leer todas las facturas
    public List<Factura> obtenerTodasLasFacturas() {
        return facturas;
    }

    // Leer una factura por número
    public Factura obtenerFacturaPorNumero(int numero) {
        for (Factura factura : facturas) {
            if (factura.getNumero() == numero) {
                return factura;
            }
        }
        return null; // Factura no encontrada
    }

    // Actualizar una factura
    public void actualizarFactura(Factura facturaActualizada) {
        for (int i = 0; i < facturas.size(); i++) {
            Factura factura = facturas.get(i);
            if (factura.getNumero() == facturaActualizada.getNumero()) {
                facturas.set(i, facturaActualizada);
                return; // Factura actualizada con éxito
            }
        }
        // Si llegamos aquí, la factura no se encontró para actualizar
        System.out.println("Factura no encontrada para actualizar.");
    }

    // Eliminar una factura
    public void eliminarFactura(int numero) {
        for (Factura factura : facturas) {
            if (factura.getNumero() == numero) {
                facturas.remove(factura);
                return; // Factura eliminada con éxito
            }
        }
        // Si llegamos aquí, la factura no se encontró para eliminar
        System.out.println("Factura no encontrada para eliminar.");
    }




}
