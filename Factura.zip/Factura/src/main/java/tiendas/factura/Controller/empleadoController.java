package tiendas.factura.Controller;

import tiendas.factura.Models.Empleado;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import tiendas.factura.Models.Main;
import java.io.*;
import tiendas.factura.Models.Cliente;

public class empleadoController {

    private List<Empleado> empleados;
    public String filePath = "C:\\Users\\BensY\\OneDrive\\Documentos\\NetBeansProjects\\Factura\\src\\main\\java\\tiendas\\factura\\Files\\empleados.txt";

    public empleadoController() {
        empleados = new ArrayList<>();
    }

   
    public void agregarEmpleado(Empleado empleado) {
        empleados.add(empleado);
    }

    public Empleado obtenerEmpleadoPorId(int id) {
        for (Empleado empleado : empleados) {
            if (empleado.getId() == id) {
                return empleado;
            }
        }
        return null;
    }
    public static Empleado obtenerEmpleadoPorIdS(int Id) {
         empleadoController empleadoController = new empleadoController();
    return empleadoController.obtenerEmpleadoPorIdS(Id);
    }

    public void actualizarEmpleado(Empleado empleadoActualizado) {
        for (int i = 0; i < empleados.size(); i++) {
            Empleado empleado = empleados.get(i);
            if (empleado.getId() == empleadoActualizado.getId()) {
                empleados.set(i, empleadoActualizado);
                break;
            }
        }
    }

    public void eliminarEmpleado(int id) {
        empleados.removeIf(empleado -> empleado.getId() == id);
    }

    public List<Empleado> obtenerEmpleados() {
        return empleados;
    }

}
