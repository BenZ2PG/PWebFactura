package tiendas.factura.Controller;

import tiendas.factura.Models.Producto;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import tiendas.factura.Models.Main;
import java.io.*;
import tiendas.factura.Models.Cliente;

public class productoController {

    private List<Producto> productos;
    private Scanner scanner;
    private String filePath = "C:\\Users\\BensY\\OneDrive\\Documentos\\NetBeansProjects\\Factura\\src\\main\\java\\tiendas\\factura\\Files\\productos.txt";

    public productoController() {
        productos = new ArrayList<>();
    }

    public static void productoMenu(Scanner scanner) {
        productoController productoController = new productoController();
        while (true) {
            System.out.println("-------- Menú de Productos --------");
            System.out.println("1. Ver producto por ID");
            System.out.println("2. Agregar un nuevo producto");
            System.out.println("3. Actualizar un producto");
            System.out.println("4. Borrar un producto");
            System.out.println("5. Salir");
            System.out.print("Elige una opción: ");
            int opcion = scanner.nextInt();
            scanner.nextLine(); // Consumir el salto de línea

            switch (opcion) {
                case 1:
                    // Buscar Producto por ID
                    System.out.print("Ingrese ID del producto a buscar: ");
                    int idBuscar = scanner.nextInt();
                    Producto productoEncontrado = productoController.obtenerProductoPorIdp(idBuscar);
                    if (productoEncontrado != null) {
                        System.out.println("Producto encontrado:");
                        System.out.println(productoEncontrado);
                    } else {
                        System.out.println("Producto no encontrado.");
                    }
                    break;
                case 2:
                    System.out.print("Ingrese ID del producto: ");
                    int idp = scanner.nextInt();
                    scanner.nextLine(); // Consume la nueva línea
                    System.out.print("Ingrese nombre del producto: ");
                    String nombre = scanner.nextLine();
                    System.out.print("Ingrese peso del producto: ");
                    String peso = scanner.nextLine();
                    System.out.print("Ingrese unidad de peso del producto: ");
                    String unidadDePeso = scanner.nextLine();
                    System.out.print("Ingrese tipo de producto: ");
                    String tipoDeProducto = scanner.nextLine();
                    System.out.print("Ingrese precio del producto: ");
                    String precio = scanner.nextLine();
                    System.out.print("Ingrese moneda del producto: ");
                    String moneda = scanner.nextLine();
                    System.out.print("Ingrese tamaño del producto: ");
                    String tamaño = scanner.nextLine();
                    System.out.print("Ingrese unidades del tamaño del producto: ");
                    String unidadesDelTamaño = scanner.nextLine();
                    System.out.print("Ingrese código del producto: ");
                    String codigo = scanner.nextLine();
                    System.out.print("Ingrese descripción del producto: ");
                    String descripcion = scanner.nextLine();

                    Producto nuevoProducto = new Producto(idp, peso, unidadDePeso, tipoDeProducto, precio, moneda,
                            tamaño, unidadesDelTamaño, codigo, nombre, descripcion);
                    productoController.agregarProducto(nuevoProducto);
                    System.out.println("Producto agregado correctamente.");
                    break;
                case 3:
                    System.out.print("Ingrese ID del producto a actualizar: ");
                    int idActualizar = scanner.nextInt();
                    scanner.nextLine(); // Consume la nueva línea
                    Producto productoActualizado = productoController.obtenerProductoPorIdp(idActualizar);
                    if (productoActualizado != null) {
                        System.out.print("Ingrese nuevo nombre del producto: ");
                        productoActualizado.setNombreProducto(scanner.nextLine());
                        // ... otros atributos a actualizar

                        productoController.actualizarProducto(idActualizar, productoActualizado);
                        System.out.println("Producto actualizado correctamente.");
                    } else {
                        System.out.println("Producto no encontrado.");
                    }
                    break;
                case 4:
                    System.out.print("Ingrese el ID del producto a eliminar: ");
                    int idEliminar = scanner.nextInt();
                    scanner.nextLine(); // Consumir el salto de línea
                    boolean eliminado = productoController.eliminarProducto(idEliminar);
                    if (eliminado) {
                        System.out.println("Producto eliminado correctamente.");
                    } else {
                        System.out.println("No se encontró el producto con el ID proporcionado.");
                    }
                    break;
                case 5:
                    return;
                default:
                    System.out.println("Opción no válida. Por favor, elige una opción válida.");
                    break;
            }
        }
    }

    public void agregarProducto(Producto producto) {
        productos.add(producto);
    }

    public Producto obtenerProductoPorIdp(int idp) {
        for (Producto producto : productos) {
            if (producto.getIdp() == idp) {
                return producto;
            }
        }
        return null;
    }

    public static Producto obtenerProductoPorIdpS(int idp) {
        productoController productoController = new productoController();
        return productoController.obtenerProductoPorIdp(idp);
    }

    public boolean actualizarProducto(int idp, Producto nuevoProducto) {
        for (int i = 0; i < productos.size(); i++) {
            if (productos.get(i).getIdp() == idp) {
                productos.set(i, nuevoProducto);
                return true;
            }
        }
        return false;
    }

    public boolean eliminarProducto(int idp) {
        for (Producto producto : productos) {
            if (producto.getIdp() == idp) {
                productos.remove(producto);
                return true;
            }
        }
        return false;
    }

    public List<Producto> obtenerProductos() {
        return productos;
    }
}
