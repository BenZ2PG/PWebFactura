package tiendas.factura.Controller;

import tiendas.factura.Models.Proveedor;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.io.*;
import tiendas.factura.Models.Main;

public class proveedorController {

    private List<Proveedor> proveedores;
    private String filePath = "C:\\Users\\BensY\\OneDrive\\Documentos\\NetBeansProjects\\Factura\\src\\main\\java\\tiendas\\factura\\Files\\proveedores.txt";

    public proveedorController() {
        proveedores = new ArrayList<>();
    }

    public static void proveedorMenu(Scanner scanner) {

        proveedorController proveedorController = new proveedorController();

        while (true) {
            System.out.println("Menú de Proveedores");
            System.out.println("1. Agregar Proveedor");
            System.out.println("2. Buscar Proveedor por ID");
            System.out.println("3. Actualizar Proveedor");
            System.out.println("4. Eliminar Proveedor");
            System.out.println("5. Listar Proveedores");
            System.out.println("0. Salir");
            System.out.print("Ingrese una opción: ");
            int opcion = scanner.nextInt();
            scanner.nextLine(); // Consume la nueva línea

            switch (opcion) {
                case 1:
                    // Agregar Proveedor
                    System.out.print("Ingrese ID del proveedor: ");
                    int id = scanner.nextInt();
                    scanner.nextLine();
                    System.out.print("Ingrese nombre del proveedor: ");
                    String nombre = scanner.nextLine();
                    System.out.print("Ingrese dirección del proveedor: ");
                    String direccion = scanner.nextLine();
                    System.out.print("Ingrese teléfono del proveedor: ");
                    String telefono = scanner.nextLine();
                    System.out.print("Ingrese email del proveedor: ");
                    String email = scanner.nextLine();
                    System.out.print("Ingrese NIT del proveedor: ");
                    String nit = scanner.nextLine();

                    Proveedor nuevoProveedor = new Proveedor(id, nombre, direccion, telefono, email, nit);
                    proveedorController.agregarProveedor(nuevoProveedor);
                    System.out.println("Proveedor agregado correctamente.");
                    break;

                case 2:
                    // Buscar Proveedor por ID
                    System.out.print("Ingrese ID del proveedor a buscar: ");
                    int idBuscar = scanner.nextInt();
                    scanner.nextLine();
                    Proveedor proveedorEncontrado = proveedorController.obtenerProveedorPorId(idBuscar);
                    if (proveedorEncontrado != null) {
                        System.out.println("Proveedor encontrado:");
                        System.out.println(proveedorEncontrado);
                    } else {
                        System.out.println("Proveedor no encontrado.");
                    }
                    break;

                case 3:
                    // Actualizar Proveedor
                    System.out.print("Ingrese ID del proveedor a actualizar: ");
                    int idActualizar = scanner.nextInt();
                    scanner.nextLine();
                    Proveedor proveedorActualizado = proveedorController.obtenerProveedorPorId(idActualizar);
                    if (proveedorActualizado != null) {
                        System.out.print("Ingrese nuevo nombre del proveedor: ");
                        proveedorActualizado.setNombre(scanner.nextLine());
                        System.out.print("Ingrese nueva dirección del proveedor: ");
                        proveedorActualizado.setDireccion(scanner.nextLine());
                        System.out.print("Ingrese nuevo teléfono del proveedor: ");
                        proveedorActualizado.setTelefono(scanner.nextLine());
                        System.out.print("Ingrese nuevo email del proveedor: ");
                        proveedorActualizado.setEmail(scanner.nextLine());
                        System.out.print("Ingrese nuevo NIT del proveedor: ");
                        proveedorActualizado.setNit(scanner.nextLine());

                        proveedorController.actualizarProveedor(proveedorActualizado);
                        System.out.println("Proveedor actualizado correctamente.");
                    } else {
                        System.out.println("Proveedor no encontrado.");
                    }
                    break;

                case 4:
                    // Eliminar Proveedor
                    System.out.print("Ingrese ID del proveedor a eliminar: ");
                    int idEliminar = scanner.nextInt();
                    proveedorController.eliminarProveedor(idEliminar);
                    System.out.println("Proveedor eliminado correctamente.");
                    break;

                case 5:
                    // Listar Proveedores
                    System.out.println("Listado de Proveedores:");
                    for (Proveedor proveedor : proveedorController.obtenerProveedores()) {
                        System.out.println(proveedor);
                    }
                    break;

                case 0:
                    Main.mainMenu(); // Volver al Menú Principal
                    return;

                default:
                    System.out.println("Opción inválida.");
                    break;
            }
        }

    }

    public void agregarProveedor(Proveedor proveedor) {
        proveedores.add(proveedor);
    }

    public Proveedor obtenerProveedorPorId(int id) {
        for (Proveedor proveedor : proveedores) {
            if (id == proveedor.getId()) {
                return proveedor;
            }
        }
        return null;
    }

    public void actualizarProveedor(Proveedor proveedorActualizado) {
        for (int i = 0; i < proveedores.size(); i++) {
            Proveedor proveedor = proveedores.get(i);
            if (proveedor.getId() == proveedorActualizado.getId()) {
                proveedores.set(i, proveedorActualizado);
                break;
            }
        }
    }

    public void eliminarProveedor(int id) {
        proveedores.removeIf(proveedor -> proveedor.getId() == id);
    }

    public List<Proveedor> obtenerProveedores() {
        return proveedores;
    }
}
