package tiendas.factura.Controller;

import tiendas.factura.Models.Empresa;
import tiendas.factura.Models.Main;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.io.*;

public class empresaController {

    private List<Empresa> empresas;
    private Scanner scanner;
    public String filePath = "C:\\Users\\BensY\\OneDrive\\Documentos\\NetBeansProjects\\Factura\\src\\main\\java\\tiendas\\factura\\Files\\empresa.txt";

    public empresaController() {
        empresas = new ArrayList<>();
    }

    public static void empresaMenu(Scanner scanner) {
        empresaController empresaController = new empresaController();
        while (true) {
            System.out.println("Menú de Empresas");
            System.out.println("1. Agregar Empresa");
            System.out.println("2. Buscar Empresa por NIT");
            System.out.println("3. Actualizar Empresa");
            System.out.println("4. Eliminar Empresa");
            System.out.println("5. Listar Empresas");
            System.out.println("0. Salir");
            System.out.print("Ingrese una opción: ");
            int opcion = scanner.nextInt();
            scanner.nextLine(); // Consume la nueva línea

            switch (opcion) {
                case 1:
                    // Agregar Empresa
                    System.out.print("Ingrese nombre de la empresa: ");
                    String nombre = scanner.nextLine();
                    System.out.print("Ingrese dirección de la empresa: ");
                    String direccion = scanner.nextLine();
                    System.out.print("Ingrese teléfono de la empresa: ");
                    String telefono = scanner.nextLine();
                    System.out.print("Ingrese email de la empresa: ");
                    String email = scanner.nextLine();
                    System.out.print("Ingrese NIT de la empresa: ");
                    String nit = scanner.nextLine();

                    Empresa nuevaEmpresa = new Empresa(nombre, direccion, telefono, email, nit);
                    empresaController.agregarEmpresa(nuevaEmpresa);
                    System.out.println("Empresa agregada correctamente.");
                    break;

                case 2:
                    // Buscar Empresa por NIT
                    System.out.print("Ingrese NIT de la empresa a buscar: ");
                    String nitBuscar = scanner.nextLine();
                    Empresa empresaEncontrada = empresaController.obtenerEmpresaPorNit(nitBuscar);
                    if (empresaEncontrada != null) {
                        System.out.println("Empresa encontrada:");
                        System.out.println(empresaEncontrada);
                    } else {
                        System.out.println("Empresa no encontrada.");
                    }
                    break;

                case 3:
                    // Actualizar Empresa
                    System.out.print("Ingrese el NIT de la empresa a actualizar: ");
                    String nitActualizar = scanner.nextLine();
                    scanner.nextLine(); // Consume la nueva línea
                    Empresa empresaActualizada = empresaController.obtenerEmpresaPorNit(nitActualizar);
                    if (empresaActualizada != null) {
                        System.out.print("Ingrese nuevo nombre de la empresa: ");
                        empresaActualizada.setNombre(scanner.nextLine());
                        System.out.print("Ingrese nueva dirección de la empresa: ");
                        empresaActualizada.setDireccion(scanner.nextLine());
                        System.out.print("Ingrese nuevo teléfono de la empresa: ");
                        empresaActualizada.setTelefono(scanner.nextLine());
                        System.out.print("Ingrese nuevo email de la empresa: ");
                        empresaActualizada.setEmail(scanner.nextLine());
                        System.out.print("Ingrese nuevo NIT de la empresa: ");
                        empresaActualizada.setNit(scanner.nextLine());
                        empresaController.actualizarEmpresa(empresaActualizada);
                        System.out.println("Empresa actualizada correctamente.");
                    } else {
                        System.out.println("Empresa no encontrada.");
                    }
                    break;

                case 4:
                    // Eliminar Empresa
                    System.out.print("Ingrese ID de la empresa a eliminar: ");
                    String nitEliminar = scanner.nextLine();
                    empresaController.eliminarEmpresa(nitEliminar);
                    System.out.println("Empresa eliminada correctamente.");
                    break;

                case 5:
                    // Listar Empresas
                    System.out.println("Listado de Empresas:");
                    for (Empresa empresa : empresaController.obtenerEmpresas()) {
                        System.out.println(empresa);
                    }
                    break;

                case 0:
                    Main.mainMenu(); // Volver al Menú Principal
                    return;
                default:
                    System.out.println("Opción inválida.");
                    break;
            }
        }
    }

    public void agregarEmpresa(Empresa empresa) {
        empresas.add(empresa);
    }

    public Empresa obtenerEmpresaPorNit(String nit) {
        for (Empresa empresa : empresas) {
            if (empresa.getNit().equals(nit)) {
                return empresa;
            }
        }
        return null;
    }

    public void actualizarEmpresa(Empresa empresaActualizada) {
        for (int i = 0; i < empresas.size(); i++) {
            Empresa empresa = empresas.get(i);
            if (empresa.getNit() == empresaActualizada.getNit()) {
                empresas.set(i, empresaActualizada);
                break;
            }
        }
    }

    public void eliminarEmpresa(String nit) {
        empresas.removeIf(empresa -> empresa.getNit() == nit);
    }

    public List<Empresa> obtenerEmpresas() {
        return empresas;
    }
}
