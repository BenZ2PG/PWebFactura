package tiendas.factura.Models;

import java.util.Scanner;
import tiendas.factura.Controller.*;

public class Main {

    public static void main(String[] args) {
        mainMenu();
    }

    public static void mainMenu() {
      
    }
}
