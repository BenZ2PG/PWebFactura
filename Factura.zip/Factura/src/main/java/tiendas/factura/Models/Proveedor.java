package tiendas.factura.Models;

import java.util.Objects;

public class Proveedor {
    private int id;
    private String nombre;
    private String direccion;
    private String telefono;
    private String email;
    private String nit;

    public Proveedor(){
    
    }
    public Proveedor(int id, String nombre, String direccion, String telefono, String email, String nit) {
        this.id = id;
        this.nombre = nombre;
        this.direccion = direccion;
        this.telefono = telefono;
        this.email = email;
        this.nit = nit;
    }

    // Getters y setters para todos los atributos

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getDireccion() {
        return direccion;
    }

    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }

    public String getTelefono() {
        return telefono;
    }

    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getNit() {
        return nit;
    }

    public void setNit(String ruc) {
        this.nit = ruc;
    }

    @Override
    public String toString() {
        return "Proveedor{" +
               "id=" + id +
               ", nombre='" + nombre + '\'' +
               ", direccion='" + direccion + '\'' +
               ", telefono='" + telefono + '\'' +
               ", email='" + email + '\'' +
               ", ruc='" + nit + '\'' +
               '}';
    }

   @Override
    public int hashCode() {
        return Objects.hash(id, nit); // Usa atributos relevantes para el hash
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || getClass() != obj.getClass()) {
            return false;
        }

        Proveedor proveedor = (Proveedor) obj;

        return id == proveedor.id && Objects.equals(nit, proveedor.nit);
    }
}