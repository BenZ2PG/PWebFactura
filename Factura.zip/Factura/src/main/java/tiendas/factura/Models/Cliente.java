package tiendas.factura.Models;

import java.util.Objects;
import tiendas.factura.Models.Usuario;

public class Cliente {

    private String nombres;
    private Usuario usuario;
    private String apellidos;
    private int cedula;
    private String email;
    private String telefono;

    // Constructores
    public Cliente() {

    }

    public Cliente(String nombres, Usuario usuario, String apellidos, int cedula, String email, String telefono) {

        this.nombres = nombres;
        this.usuario = usuario;
        this.apellidos = apellidos;
        this.cedula = cedula;
        this.email = email;
        this.telefono = telefono;
    }

    // Getters y setters
    public String getNombres() {
        return nombres;
    }

    public void setNombres(String nombres) {
        this.nombres = nombres;
    }

    public Usuario getUsuario() {
        return usuario;
    }

    public void setUsuario(Usuario usuario) {
        this.usuario = usuario;
    }
    
    public String getApellidos() {
        return apellidos;
    }

    public void setApellidos(String apellidos) {
        this.apellidos = apellidos;
    }

    public int getCedula() {
        return cedula;
    }

    public void setCedula(int cedula) {
        this.cedula = cedula;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getTelefono() {
        return telefono;
    }

    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }

    // Método toString
    @Override
    public String toString() {
        return "Cliente{"
                +  "nombres='" + nombres + '\''
                +  "usuario='" + usuario + '\''
                + ", apellidos='" + apellidos + '\''
                +", cedula='" + cedula + '\''
                + ", email='" + email + '\''
                + ", telefono='" + telefono + '\''
                + '}';
    }

    // Métodos hashCode y equals
    @Override
    public int hashCode() {
        return Objects.hash(cedula);
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || getClass() != obj.getClass()) {
            return false;
        }
        Cliente cliente = (Cliente) obj;
        return cedula == cliente.cedula;
    }
}
