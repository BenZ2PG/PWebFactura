package tiendas.factura.Models;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import tiendas.factura.Models.Empleado;
import tiendas.factura.Models.Sucursal;
import tiendas.factura.Models.Cliente;
import tiendas.factura.Models.Producto;
import java.util.Objects;

public class Factura {
    private int numero;
    private String fecha;
    private Cliente cliente;
    private Empleado empleado;
    private Sucursal sucursal;
    private Producto productos;

    public Factura() {
        
    }

public Factura(int numero, String fecha, Cliente cliente, Empleado empleado, Sucursal sucursal, Producto productos) {
    this.numero = numero;
    this.fecha = fecha;
    this.cliente = cliente;
    this.empleado = empleado;
    this.sucursal = sucursal;
    this.productos = productos;
}

    // Getters y setters para todos los atributos

    public int getNumero() {
        return numero;
    }

    public void setNumero(int numero) {
        this.numero = numero;
    }

    public String getFecha() {
        return fecha;
    }

    public void setFecha(String fecha) {
        this.fecha = fecha;
    }

    public Cliente getCliente() {
        return cliente;
    }

    public void setCliente(Cliente cliente) {
        this.cliente = cliente;
    }

    public Empleado getEmpleado() {
        return empleado;
    }

    public void setEmpleado(Empleado empleado) {
        this.empleado = empleado;
    }

    public Sucursal getSucursal() {
        return sucursal;
    }

    public void setSucursal(Sucursal sucursal) {
        this.sucursal = sucursal;
    }

    public Producto getProductos() {
        return productos;
    }

    public void setProducto(Producto producto) {
        this.productos = producto;
    }

    @Override
    public String toString() {
        return "Factura{" +
               "numero=" + numero +
               ", fecha=" + fecha +
               ", cliente=" + cliente +
               ", empleado=" + empleado +
               ", sucursal=" + sucursal +
               ", productos=" + productos +
               '}';
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || getClass() != obj.getClass()) {
            return false;
        }

        Factura factura = (Factura) obj;

        return numero == factura.numero;
    }
}