package tiendas.factura.Models;

import tiendas.factura.Models.Usuario.*;
import java.util.Objects;

public class Empleado {
    private int id;
    private Usuario usuario;
    private String nombres;
    private String apellidos;
    private String cedula;
    private String email;
    private String telefono;
    private String cargo;

    public Empleado(int id, Usuario usuario, String nombres, String apellidos, String cedula,
                    String email, String telefono, String cargo) {
        this.id = id;
        this.usuario = usuario;
        this.nombres = nombres;
        this.apellidos = apellidos;
        this.cedula = cedula;
        this.email = email;
        this.telefono = telefono;
        this.cargo = cargo;
    }

    // Getters y setters para todos los atributos

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public Usuario getUsuario() {
        return usuario;
    }

    public void setUsuario(Usuario usuario) {
        this.usuario = usuario;
    }
    

    public String getNombres() {
        return nombres;
    }

    public void setNombres(String nombres) {
        this.nombres = nombres;
    }

    public String getApellidos() {
        return apellidos;
    }

    public void setApellidos(String apellidos) {
        this.apellidos = apellidos;
    }

    public String getCedula() {
        return cedula;
    }

    public void setCedula(String cedula) {
        this.cedula = cedula;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getTelefono() {
        return telefono;
    }

    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }

    public String getCargo() {
        return cargo;
    }

    public void setCargo(String cargo) {
        this.cargo = cargo;
    }

    @Override
    public String toString() {
        return "Empleado{" +
               "id=" + id +
                ", usuario='"+usuario+ '\'' +
               ", nombres='" + nombres + '\'' +
               ", apellidos='" + apellidos + '\'' +
               ", cedula='" + cedula + '\'' +
               ", email='" + email + '\'' +
               ", telefono='" + telefono + '\'' +
               ", cargo='" + cargo + '\'' +
               '}';
    }

    @Override
    public int hashCode() {
        return Objects.hash(id, cedula); // Usa atributos relevantes para el hash
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || getClass() != obj.getClass()) {
            return false;
        }

        Empleado empleado = (Empleado) obj;

        return id == empleado.id && Objects.equals(cedula, empleado.cedula);
    }
}