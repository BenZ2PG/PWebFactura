package tiendas.factura.Models;

import java.util.Date;
import java.util.Objects;
import tiendas.factura.Models.Proveedor;
import tiendas.factura.Models.Sucursal;

public class Compra {

    private int numero;
    private Date fecha;
    private Proveedor proveedor;
    private Sucursal sucursal;

    public Compra(){
    
    }
    public Compra(int numero, Date fecha, Proveedor proveedor, Sucursal sucursal) {
        this.numero = numero;
        this.fecha = fecha;
        this.proveedor = proveedor;
        this.sucursal = sucursal;
    }

    // Getters y setters para todos los atributos
    public int getNumero() {
        return numero;
    }

    public void setNumero(int numero) {
        this.numero = numero;
    }

    public Date getFecha() {
        return fecha;
    }

    public void setFecha(Date fecha) {
        this.fecha = fecha;
    }

    public Proveedor getProveedor() {
        return proveedor;
    }

    public void setProveedor(Proveedor proveedor) {
        this.proveedor = proveedor;
    }

    public Sucursal getSucursal() {
        return sucursal;
    }

    public void setSucursal(Sucursal sucursal) {
        this.sucursal = sucursal;
    }

    @Override
    public String toString() {
        return "Compra{"
                + "numero=" + numero
                + ", fecha=" + fecha
                + ", proveedor=" + proveedor
                + ", sucursal=" + sucursal
                + '}';
    }

    @Override
    public int hashCode() {
        return Objects.hash(numero, fecha, proveedor, sucursal);
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || getClass() != obj.getClass()) {
            return false;
        }

        Compra compra = (Compra) obj;

        return numero == compra.numero
                && Objects.equals(fecha, compra.fecha)
                && Objects.equals(proveedor, compra.proveedor)
                && Objects.equals(sucursal, compra.sucursal);
    }
}
