package tiendas.factura.Models;

import java.util.Objects;

public class Producto {

    private int idp;
    private String peso;
    private String unidadDePeso;
    private String tipoDeProducto;
    private String precio;
    private String moneda;
    private String tamaño;
    private String unidadesDelTamaño;
    private String codigo;
    private String nombreProducto;
    private String descripcion;

    public Producto(){
    
    }
    public Producto(int idp, String peso, String unidadDePeso, String tipoDeProducto,
            String precio, String moneda, String tamaño, String unidadesDelTamaño,
            String codigo, String nombreProducto, String descripcion) {
        this.idp = idp;
        this.peso = peso;
        this.unidadDePeso = unidadDePeso;
        this.tipoDeProducto = tipoDeProducto;
        this.precio = precio;
        this.moneda = moneda;
        this.tamaño = tamaño;
        this.unidadesDelTamaño = unidadesDelTamaño;
        this.codigo = codigo;
        this.nombreProducto = nombreProducto;
        this.descripcion = descripcion;
    }

    // Getters y setters para todos los atributos
    public int getIdp() {
        return idp;
    }

    public void setIdp(int idp) {
        this.idp = idp;
    }

    public String getPeso() {
        return peso;
    }

    public void setPeso(String peso) {
        this.peso = peso;
    }

    public String getUnidadDePeso() {
        return unidadDePeso;
    }

    public void setUnidadDePeso(String unidadDePeso) {
        this.unidadDePeso = unidadDePeso;
    }

    public String getTipoDeProducto() {
        return tipoDeProducto;
    }

    public void setTipoDeProducto(String tipoDeProducto) {
        this.tipoDeProducto = tipoDeProducto;
    }

    public String getPrecio() {
        return precio;
    }

    public void setPrecio(String precio) {
        this.precio = precio;
    }

    public String getMoneda() {
        return moneda;
    }

    public void setMoneda(String moneda) {
        this.moneda = moneda;
    }

    public String getTamaño() {
        return tamaño;
    }

    public void setTamaño(String tamaño) {
        this.tamaño = tamaño;
    }

    public String getUnidadesDelTamaño() {
        return unidadesDelTamaño;
    }

    public void setUnidadesDelTamaño(String unidadesDelTamaño) {
        this.unidadesDelTamaño = unidadesDelTamaño;
    }

    public String getCodigo() {
        return codigo;
    }

    public void setCodigo(String codigo) {
        this.codigo = codigo;
    }

    public String getNombreProducto() {
        return nombreProducto;
    }

    public void setNombreProducto(String nombreProducto) {
        this.nombreProducto = nombreProducto;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    @Override
    public String toString() {
        return "Producto{"
                + "id=" + idp
                + ", peso=" + peso
                + ", unidadDePeso='" + unidadDePeso + '\''
                + ", tipoDeProducto='" + tipoDeProducto + '\''
                + ", precio=" + precio
                + ", moneda='" + moneda + '\''
                + ", tamaño='" + tamaño + '\''
                + ", unidadesDelTamaño=" + unidadesDelTamaño
                + ", codigo='" + codigo + '\''
                + ", nombreProducto='" + nombreProducto + '\''
                + ", descripcion='" + descripcion + '\''
                + '}';
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || getClass() != obj.getClass()) {
            return false;
        }

        Producto producto = (Producto) obj;

        return idp == producto.idp && Objects.equals(codigo, producto.codigo);
    }
}
