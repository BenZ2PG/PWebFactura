package tiendas.factura.Models;

import java.util.Date;
import tiendas.factura.Models.Factura;
import tiendas.factura.Models.Usuario;
import java.util.Objects;

public class Venta {
    private int numero;
    private Date fecha;
    private Factura factura;
    private Usuario usuario;

    public Venta(){
    }
    public Venta(int numero, Date fecha, Factura factura, Usuario usuario) {
        this.numero = numero;
        this.fecha = fecha;
        this.factura = factura;
        this.usuario = usuario;
    }

    // Getters y setters para todos los atributos

    public int getNumero() {
        return numero;
    }

    public void setNumero(int numero) {
        this.numero = numero;
    }

    public Date getFecha() {
        return fecha;
    }

    public void setFecha(Date fecha) {
        this.fecha = fecha;
    }

    public Factura getFactura() {
        return factura;
    }

    public void setFactura(Factura factura) {
        this.factura = factura;
    }

    public Usuario getUsuario() {
        return usuario;
    }

    public void setUsuario(Usuario usuario) {
        this.usuario = usuario;
    }

    @Override
    public String toString() {
        return "Venta{" +
               "numero=" + numero +
               ", fecha=" + fecha +
               ", factura=" + factura +
               ", usuario=" + usuario +
               '}';
    }

    @Override
    public int hashCode() {
        return Objects.hash(numero, fecha, factura, usuario);
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || getClass() != obj.getClass()) {
            return false;
        }

        Venta venta = (Venta) obj;

        return numero == venta.numero &&
               Objects.equals(fecha, venta.fecha) &&
               Objects.equals(factura, venta.factura) &&
               Objects.equals(usuario, venta.usuario);
    }
}