package tiendas.factura.Models;

import java.util.Objects;

public class Empresa {
    private String nombre;
    private String direccion;
    private String telefono;
    private String email;
    private String nit;

    public Empresa(String nombre, String direccion, String telefono, String email, String nit) {
        this.nombre = nombre;
        this.direccion = direccion;
        this.telefono = telefono;
        this.email = email;
        this.nit = nit;
    }

    // Getters y setters para todos los atributos

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getDireccion() {
        return direccion;
    }

    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }

    public String getTelefono() {
        return telefono;
    }

    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getNit() {
        return nit;
    }

    public void setNit(String nit) {
        this.nit = nit;
    }

    @Override
    public String toString() {
        return "Empresa{" +
               "nombre='" + nombre + '\'' +
               ", direccion='" + direccion + '\'' +
               ", telefono='" + telefono + '\'' +
               ", email='" + email + '\'' +
               ", Nit='" + nit + '\'' +
               '}';
    }

    @Override
    public int hashCode() {
        return Objects.hash(nombre, nit); // Usa atributos relevantes para el hash
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || getClass() != obj.getClass()) {
            return false;
        }

        Empresa empresa = (Empresa) obj;

        return Objects.equals(nombre, empresa.nombre) && Objects.equals(nit, empresa.nit);
    }
}