package tiendas.factura.Models;

import java.util.Objects;

public class Sucursal {
    private int ids;
    private String nombre;
    private String direccion;
    private String telefono;

    public Sucursal(int ids, String nombre, String direccion, String telefono) {
        this.ids = ids;
        this.nombre = nombre;
        this.direccion = direccion;
        this.telefono = telefono;
    }

    // Getters y setters para todos los atributos

    public int getIds() {
        return ids;
    }

    public void setId(int ids) {
        this.ids = ids;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getDireccion() {
        return direccion;
    }

    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }

    public String getTelefono() {
        return telefono;
    }

    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }

    @Override
    public String toString() {
        return "Sucursal{" +
               "id=" + ids +
               ", nombre='" + nombre + '\'' +
               ", direccion='" + direccion + '\'' +
               ", telefono='" + telefono + '\'' +
               '}';
    }

    @Override
    public int hashCode() {
        return Objects.hash(ids, nombre); // Usa atributos relevantes para el hash
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || getClass() != obj.getClass()) {
            return false;
        }

        Sucursal sucursal = (Sucursal) obj;

        return ids == sucursal.ids && Objects.equals(nombre, sucursal.nombre);
    }
}
